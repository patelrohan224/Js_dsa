const mongoose=require('mongoose');
const galleryShema=new mongoose.Schema({
    image_urls:[{type:String,required:true}],
    user_id:{type:mongoose.Schema.Types.ObjectId, ref:"product",required:true}
})
module.exports=mongoose.model("gallery",galleryShema)